# vehicle > 2024-07-09 11:48pm
https://universe.roboflow.com/vehicle-ug2tj/vehicle-yioma

Provided by a Roboflow user
License: CC BY 4.0

