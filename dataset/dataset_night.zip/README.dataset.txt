# Car > 2024-07-09 9:52am
https://universe.roboflow.com/sara-ramezani/car-xi0dq

Provided by a Roboflow user
License: CC BY 4.0

